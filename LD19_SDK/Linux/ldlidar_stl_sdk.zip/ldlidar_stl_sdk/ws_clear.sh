#!/bin/bash
#Author: David Hu
#Date: 2021-11
rm -rf build/
echo "del ./build/"
echo "del is ok....."